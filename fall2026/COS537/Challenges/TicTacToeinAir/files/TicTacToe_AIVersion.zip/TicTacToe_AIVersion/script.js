const board = document.getElementById("board");
const status = document.getElementById("status");

let cells = [];
let currentPlayer = "X";
let boardState = Array(9).fill(null);

// Load TensorFlow.js
let model;
let replayMemory = [];

// Create the game board
function createBoard() {
    board.innerHTML = "";
    cells = [];
    for (let i = 0; i < 9; i++) {
        const cell = document.createElement("div");
        cell.classList.add("cell");
        cell.dataset.index = i;
        cell.addEventListener("click", handleMove);
        board.appendChild(cell);
        cells.push(cell);
    }
}

// Handle player's move
function handleMove(event) {
    const index = event.target.dataset.index;
    if (!boardState[index] && currentPlayer === "X") {
        boardState[index] = currentPlayer;
        event.target.textContent = currentPlayer;

        if (checkWin()) {
            status.textContent = `Player X Wins!`;
            disableBoard();
            return;
        }

        if (boardState.every(cell => cell)) {
            status.textContent = "It's a Draw!";
            return;
        }

        currentPlayer = "O";
        status.textContent = "AI's Turn";
        setTimeout(aiMove, 500);
    }
}

// AI selects the best move
async function aiMove() {
    let bestMove = await predictBestMove(boardState);
    boardState[bestMove] = "O";
    cells[bestMove].textContent = "O";

    if (checkWin()) {
        status.textContent = `AI Wins!`;
        disableBoard();
        return;
    }

    if (boardState.every(cell => cell)) {
        status.textContent = "It's a Draw!";
        return;
    }

    currentPlayer = "X";
    status.textContent = "Player X's Turn";
}

// Minimax Algorithm (AI Decision-Making)
function minimax(board, depth, isMaximizing) {
    let winner = checkWinner(board);
    if (winner === "O") return 10 - depth;
    if (winner === "X") return depth - 10;
    if (board.every(cell => cell !== null)) return 0;

    if (isMaximizing) {
        let bestScore = -Infinity;
        for (let i = 0; i < 9; i++) {
            if (!board[i]) {
                board[i] = "O";
                let score = minimax(board, depth + 1, false);
                board[i] = null;
                bestScore = Math.max(score, bestScore);
            }
        }
        return bestScore;
    } else {
        let bestScore = Infinity;
        for (let i = 0; i < 9; i++) {
            if (!board[i]) {
                board[i] = "X";
                let score = minimax(board, depth + 1, true);
                board[i] = null;
                bestScore = Math.min(score, bestScore);
            }
        }
        return bestScore;
    }
}

function bestMove(board) {
    let bestScore = -Infinity;
    let move;
    for (let i = 0; i < 9; i++) {
        if (!board[i]) {
            board[i] = "O";
            let score = minimax(board, 0, false);
            board[i] = null;
            if (score > bestScore) {
                bestScore = score;
                move = i;
            }
        }
    }
    return move;
}

// Train AI Model with Minimax Data
async function trainModel() {
    model = tf.sequential();
    model.add(tf.layers.dense({ inputShape: [9], units: 128, activation: "relu" }));
    model.add(tf.layers.dense({ units: 64, activation: "relu" }));
    model.add(tf.layers.dense({ units: 32, activation: "relu" }));
    model.add(tf.layers.dense({ units: 9, activation: "softmax" }));

    model.compile({ optimizer: "adam", loss: "meanSquaredError" });

    let inputs = [];
    let outputs = [];

    for (let i = 0; i < 50000; i++) {
        let state = Array(9).fill(null).map(() => Math.random() > 0.5 ? "X" : "O");
        let move = bestMove(state);
        let output = Array(9).fill(0);
        output[move] = 1;

        inputs.push(state.map(cell => (cell === "X" ? 1 : cell === "O" ? -1 : 0)));
        outputs.push(output);
    }

    let xs = tf.tensor2d(inputs);
    let ys = tf.tensor2d(outputs);

    await model.fit(xs, ys, { epochs: 100, batchSize: 32 });

    console.log("AI Model trained with Minimax data!");
}

// Predict best move
async function predictBestMove(state) {
    let input = tf.tensor2d([state.map(cell => (cell === "X" ? 1 : cell === "O" ? -1 : 0))]);
    let prediction = model.predict(input).dataSync();

    // Sort moves by highest probability first
    let moveRanks = Array.from(prediction)
        .map((value, index) => ({ index, value }))
        .sort((a, b) => b.value - a.value);

    // Pick the best available move
    for (let i = 0; i < moveRanks.length; i++) {
        let bestMove = moveRanks[i].index;
        if (state[bestMove] === null) {
            storeExperience(state, bestMove); // Store experience for future learning
            return bestMove;
        }
    }

    // Fallback: Pick any available move if needed
    let availableMoves = boardState.map((v, i) => v === null ? i : null).filter(v => v !== null);
    return availableMoves.length ? availableMoves[0] : null;
}


// Experience Replay (Learning from Past Games)
function storeExperience(state, move) {
    if (replayMemory.length > 10000) replayMemory.shift();
    replayMemory.push({ state, move });
}

async function trainFromReplay() {
    let inputs = [];
    let outputs = [];

    for (let data of replayMemory) {
        let output = Array(9).fill(0);
        output[data.move] = 1;
        inputs.push(data.state.map(cell => (cell === "X" ? 1 : cell === "O" ? -1 : 0)));
        outputs.push(output);
    }

    let xs = tf.tensor2d(inputs);
    let ys = tf.tensor2d(outputs);

    await model.fit(xs, ys, { epochs: 50, batchSize: 32 });

    console.log("AI improved from replay memory!");
}

// Check for win condition
function checkWin() {
    const winningCombos = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
    ];
    return winningCombos.some(combo => {
        const [a, b, c] = combo;
        return boardState[a] && boardState[a] === boardState[b] && boardState[a] === boardState[c];
    });
}

function checkWinner(board) {
    if (checkWin(board, "O")) return "O";
    if (checkWin(board, "X")) return "X";
    return null;
}

// Disable board after game ends
function disableBoard() {
    cells.forEach(cell => cell.removeEventListener("click", handleMove));
}

// Reset game
function resetGame() {
    boardState.fill(null);
    currentPlayer = "X";
    status.textContent = "Player X's Turn";
    createBoard();
}

// Start the game
createBoard();
trainModel();
